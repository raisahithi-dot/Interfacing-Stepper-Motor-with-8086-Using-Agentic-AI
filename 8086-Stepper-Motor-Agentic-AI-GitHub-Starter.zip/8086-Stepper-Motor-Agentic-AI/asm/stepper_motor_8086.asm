; Interfacing Stepper Motor with 8086 through 8255 PPI
; Educational MASM/TASM-style example.
;
; IMPORTANT:
; 1. Verify the I/O addresses for your specific trainer board / simulator.
; 2. Do NOT drive motor coils directly from 8255. Use a suitable motor driver.
; 3. This example repeats clockwise full-step patterns continuously.
; 4. Adapt assembler directives if your lab tool uses different syntax.

.MODEL SMALL
.STACK 100H

PORTC   EQU 0FFC4H       ; Example only: 8255 Port C address
CTRL8255 EQU 0FFC6H      ; Example only: 8255 control-register address

.DATA
; Two-phase full-step pattern on the low four bits.
; Confirm phase order and wiring for your motor/driver.
PHASES  DB 03H, 06H, 0CH, 09H

.CODE
START:
    MOV AX, @DATA
    MOV DS, AX

    ; Configure 8255 ports as outputs, Mode 0.
    MOV DX, CTRL8255
    MOV AL, 80H
    OUT DX, AL

    MOV SI, OFFSET PHASES

MAIN_LOOP:
    MOV SI, OFFSET PHASES
    MOV CX, 4

NEXT_PHASE:
    MOV DX, PORTC
    MOV AL, [SI]
    OUT DX, AL
    CALL DELAY

    INC SI
    LOOP NEXT_PHASE

    JMP MAIN_LOOP

; Software delay. Actual timing depends on CPU/emulator clock.
DELAY PROC
    PUSH CX
    MOV CX, 0FFFFH
DELAY_LOOP:
    LOOP DELAY_LOOP
    POP CX
    RET
DELAY ENDP

END START
