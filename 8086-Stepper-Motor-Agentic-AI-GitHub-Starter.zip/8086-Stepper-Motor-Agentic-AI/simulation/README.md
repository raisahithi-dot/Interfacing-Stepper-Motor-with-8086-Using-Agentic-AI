# Simulation files

Place the real simulator project and supporting files here, for example:
- Proteus project file(s) created by you
- Any required circuit library/configuration files that can legally be shared
- A short note naming the simulator version and how to run it

No simulator project is included in this starter package because circuit files depend on the exact design and simulator version. Do not rename a placeholder as if it were a working simulation.
