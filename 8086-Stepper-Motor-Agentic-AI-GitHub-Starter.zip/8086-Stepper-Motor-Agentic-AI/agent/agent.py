"""
Rule-based supervisory planning agent for the 8086 stepper-motor project.

This is a transparent educational agent, not a trained ML model and not a
direct hardware interface. It creates a plan that can be reviewed and used
to configure/test the assembly program. Live control needs a separate,
implemented communication bridge and matching firmware.
"""
from csv import writer
from pathlib import Path

PHASES_CW = [0x03, 0x06, 0x0C, 0x09]
PHASES_CCW = list(reversed(PHASES_CW))


def recommend_delay(speed: str) -> int:
    """Return a software-loop recommendation; not a calibrated time value."""
    return {"slow": 50000, "medium": 25000, "fast": 10000}[speed]


def build_plan(direction: str, steps: int, speed: str) -> list[dict]:
    phases = PHASES_CW if direction == "clockwise" else PHASES_CCW
    delay = recommend_delay(speed)
    return [
        {
            "step_number": n + 1,
            "direction": direction,
            "phase_pattern_hex": f"0x{phases[n % len(phases)]:02X}",
            "delay_loop_count_recommendation": delay,
            "speed_profile": speed,
        }
        for n in range(steps)
    ]


def main() -> None:
    print("8086 Stepper Motor — Supervisory Planning Agent")
    print("This creates a plan only; it does not connect to motor hardware.\n")

    direction = input("Direction (clockwise/anticlockwise) [clockwise]: ").strip().lower()
    if not direction:
        direction = "clockwise"
    if direction in {"anticlockwise", "counterclockwise", "ccw"}:
        direction = "anticlockwise"
    elif direction in {"clockwise", "cw"}:
        direction = "clockwise"
    else:
        raise SystemExit("Invalid direction. Choose clockwise or anticlockwise.")

    raw_steps = input("Number of steps (1–2000) [40]: ").strip() or "40"
    try:
        steps = int(raw_steps)
    except ValueError:
        raise SystemExit("Steps must be an integer.")
    if not 1 <= steps <= 2000:
        raise SystemExit("Choose a step count from 1 to 2000.")

    speed = input("Speed profile (slow/medium/fast) [medium]: ").strip().lower() or "medium"
    if speed not in {"slow", "medium", "fast"}:
        raise SystemExit("Choose slow, medium, or fast.")

    plan = build_plan(direction, steps, speed)
    output = Path("agent_plan.csv")
    with output.open("w", newline="", encoding="utf-8") as f:
        csv_writer = writer(f)
        csv_writer.writerow(plan[0].keys())
        for row in plan:
            csv_writer.writerow(row.values())

    print(f"\nPlan created: {len(plan)} steps")
    print(f"Direction: {direction}; speed profile: {speed}")
    print(f"Recommended delay-loop count: {recommend_delay(speed)}")
    print("First phase patterns:", ", ".join(row["phase_pattern_hex"] for row in plan[:8]))
    print(f"Saved CSV: {output.resolve()}")
    print("\nReminder: delay-loop counts are illustrative and must be calibrated for your setup.")


if __name__ == "__main__":
    main()
