# Test Plan and Results

Fill in this document only after running the actual software/simulation/hardware.

| Test | Input / setup | Expected result | Actual result |
|---|---|---|---|
| Python input validation | Invalid direction | Agent reports invalid input | Not tested |
| Step count validation | 0 or >2000 | Agent rejects the value | Not tested |
| Clockwise plan | 8 steps, medium | CW phase pattern repeats in order | Not tested |
| Anticlockwise plan | 8 steps, medium | Reverse phase order is produced | Not tested |
| Assembly compile | Your assembler | No assembly errors | Not tested |
| Simulation | Your circuit and addresses | Motor model advances in selected direction | Not tested |
| Hardware test (optional) | Verified trainer and driver | Motor turns without overheating or wiring faults | Not tested |

## Results

Replace this section with your real observations, screenshots, tool versions, and any limitations encountered. Never mark a test as passed unless it was performed.
