# Agentic AI Component

## Purpose

The Python component acts as a supervisory planning agent. It takes a user's motion goal and converts it into a structured phase plan.

## Inputs

- Direction: clockwise or anticlockwise
- Requested number of steps
- Speed profile: slow, medium, or fast

## Agent workflow

1. **Perceive:** read the requested direction, step count, and speed profile.
2. **Validate:** reject unsupported directions, invalid numbers, and out-of-range step counts.
3. **Plan:** choose the phase order and a suggested delay-loop count.
4. **Act (software artifact):** write a CSV plan for inspection and testing.
5. **Evaluate:** a user can compare the plan with expected patterns and record results in the test plan.

## Important limitation

This is a rule-based planning agent, not a generative model or trained AI system. In this starter repository, it does not send live commands to the 8086 board and does not receive motor feedback. To demonstrate genuine agent-to-hardware operation, implement and document a communication interface, a command protocol, error handling, and safe stop behavior. Do not claim closed-loop control without sensor feedback.
