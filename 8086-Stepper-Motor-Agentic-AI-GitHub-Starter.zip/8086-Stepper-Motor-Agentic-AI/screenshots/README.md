# Screenshots

Add genuine screenshots of:
1. The circuit and connections
2. The assembly program running / output pattern
3. The motor movement or logic-state trace
4. The Python agent output and generated CSV plan

Do not upload mock screenshots as proof of hardware operation.
