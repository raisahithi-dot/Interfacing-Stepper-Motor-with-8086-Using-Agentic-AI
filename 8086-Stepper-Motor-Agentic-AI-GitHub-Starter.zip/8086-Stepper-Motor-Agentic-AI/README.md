# Interfacing Stepper Motor with 8086 Using Agentic AI

An educational starter project combining:
1. 8086 assembly to send step sequences through an 8255 PPI.
2. A Python command-line planning agent that recommends direction, step count, and delay.
3. Documentation for the circuit, simulation, testing, and limitations.

> **Important:** The 8255 I/O addresses in `asm/stepper_motor_8086.asm` are examples taken from a common trainer-kit arrangement. Your trainer board / Proteus circuit may use different addresses. Verify them before running the program. Do not connect a motor winding directly to an 8255 output; use a suitable motor driver.

## Repository structure

```text
8086-Stepper-Motor-Agentic-AI/
├── README.md
├── LICENSE
├── requirements.txt
├── .gitignore
├── asm/
│   └── stepper_motor_8086.asm
├── agent/
│   └── agent.py
├── docs/
│   ├── circuit_and_interfacing.md
│   ├── agentic_ai_design.md
│   └── test_plan.md
├── simulation/
│   └── README.md
└── screenshots/
    └── README.md
```

## Hardware concept

8086 CPU → 8255 PPI → motor driver (for example, ULN2003A when appropriate for the motor) → stepper motor.

The 8255 supplies logic-level control patterns; the driver handles the motor-coil current. Confirm motor type, coil wiring, supply voltage, driver ratings, and common ground from the component datasheets.

## Software

- 8086 assembly: `asm/stepper_motor_8086.asm`
- Python planning agent: `agent/agent.py`
- Python version: 3.9 or newer
- Python dependencies: none (standard library only)

## Run the planning agent

From the repository root:

```bash
python agent/agent.py
```

The agent asks for a target direction and number of steps, validates the inputs, recommends a delay value, and prints a phase plan. It can also save the plan as `agent_plan.csv`.

**Integration note:** This starter demonstrates an AI-agent-style supervisory planner; it does **not** directly transmit commands from Python to a physical 8086 board. Live control requires a defined communication path (for example, a serial interface plus matching firmware/hardware). Do not describe the system as closed-loop or autonomous hardware control unless that connection has actually been implemented and tested.

## Run the assembly program

Assemble using a toolchain compatible with the syntax you use (for example, MASM/TASM-style assemblers) or adapt it to your lab trainer's assembler. Load/run it on a compatible 8086 trainer or in a correctly configured simulator.

The sample uses:
- 8255 control register: `FFC6h`
- Port C: `FFC4h`
- Control word: `80h` (Mode 0, ports configured as outputs)

These are **board-specific example addresses**, not universal 8086 addresses. Update the `EQU` values to match your board.

## What to add before submission

- A screenshot of your actual circuit in `simulation/`
- The simulator project file, if you built one (for example, a Proteus project)
- A screenshot of a successful run in `screenshots/`
- Your measured observations / results in `docs/test_plan.md`
- Names and contributions of project members, if applicable

Do not upload fabricated screenshots or claim hardware testing that was not performed.
